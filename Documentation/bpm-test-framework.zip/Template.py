def Template(RFObject,
             BPMObject,
             argument1=1,
             argument2=2,
             argument3=3,
             settling_time=1,
             ReportObject=None):

    # Readies text that will introduce this test in the report
    intro = r"This is a template test"

    # Formats the name of plot that is saved as
    test_name = __name__
    test_name = test_name.rsplit("Tests.")[1]
    test_name = test_name.replace("_", " ")
    print("Starting test \"" + test_name + "\"")

    # Readies devices that are used in the test for the report 
    device_names = []
    device_names.append(RFObject.get_device_ID())
    device_names.append(BPMObject.get_device_ID())

    # Readies parameters that are used in the test for the report
    parameter_names = []
    parameter_names.append("Argument1: " + str(argument1))
    parameter_names.append("Argument2: " + str(argument2))
    parameter_names.append("Argument3: " + str(argument3))

    #######Change these lines with the test you wish to perform#######
    x = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    y = []
    for index in x:
        time.sleep(settling_time)
        y.append(2*index)
    ###################################################################
    
    # plots the test results
    plt.plot(x,y)

    if report == None:
        # If no report is entered as an input to the test, display results
        plt.show()
    else:
        # If there is a report for the data to be copied to, do so.
        plt.savefig(test_name + ".pdf")
        ReportObject.setup_test(test_name, intro, device_names, parameter_names)
        ReportObject.add_figure_to_test(test_name)