from abc import ABCMeta, abstractmethod

class Generic_RFSigGen():
    __metaclass__ = ABCMeta # Allows for abstract methods to be created.

    @abstractmethod
    def get_device_ID(self):
        pass

    @abstractmethod
    def set_frequency(self,frequency):
        pass

    @abstractmethod
    def get_frequency(self):
        pass

    @abstractmethod
    def set_output_power(self, power):
        pass

    @abstractmethod
    def get_output_power(self):
        pass

    @abstractmethod
    def turn_on_RF(self):
        pass

    @abstractmethod
    def turn_off_RF(self):
        pass

    @abstractmethod
    def get_output_state(self):
        pass

    @abstractmethod
    def set_output_power_limit(self, limit):
        pass

    @abstractmethod
    def get_output_power_limit(self):
        pass





