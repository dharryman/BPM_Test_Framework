  # Public method to get the BPM current
  def get_beam_current(self):  
    # Get the current (in mA) from the PV in the database hosted on the BPM
    current = self._read_epics_pv(".Current") 
    # Gets the mean value for current if it returns more than one sample
    current = np.mean(current)  
    # Returns the mean current calculated by the BPM
    return current
  
  # Public Method to get the BPM Power
  def get_input_power(self):
    # This BPM does not calculate input power, so 0 is used instead
    return 0.0
  
  # Public Method to get the RAW ADC counts of each pickup 
  def get_raw_BPM_buttons(self):
    # Returns the number of counts on each ADC, each PV only returns one sample
    a = self._read_epics_pv(".ADC.A")
    b = self._read_epics_pv(".ADC.B") 
    c = self._read_epics_pv(".ADC.C") 
    d = self._read_epics_pv(".ADC.D")
    # Return all four ADC values
    return a, b, c, d
    
  def get_ADC_sum(self):
    # Gets the raw counts of each pickup 
    a, b, c, d = self.get_raw_BPM_buttons()
    # adds all of the counts from the pickups together to obtain the sum
    ADCSum = a + b + c + d
    # Returns the total number of ADC counts
    return ADCSum 