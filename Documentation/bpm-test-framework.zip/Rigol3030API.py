class Rigol3030DSG_RFSigGen(Generic_RFSigGen):

  def __init__(self, ipaddress, port = 5555, timeout = 1, limit=-40):
    # timeout for the telnet comms
    self.timeout = timeout  
    # connects to the telnet device
    self.tn = telnetlib.Telnet(ipaddress, port, self.timeout) 
    # gets the device of the telnet device, makes sure its the right one
    self.get_device_ID()  
    # turn off the RF output
    self.turn_off_RF()  
    # set the RF output limit
    self.set_output_power_limit(limit)  

  def _telnet_query(self, message):
    self._telnet_write(message)
    return self._telnet_read()

  def _telnet_write(self, message):
    # Checks that the telnet message is a string
    if type(message) != str:
      raise TypeError
    # Writes a telnet message with termination characters
    self.tn.write(message + "\r\n") 

  def _telnet_read(self):
    # Telnet reply, with termination chars removed
    return self.tn.read_until("\n", self.timeout).rstrip('\n')  
    
